# autossuficiencia

Disponível na Playstore
https://play.google.com/store/apps/details?id=com.autossuficiencia

Para computador e iPhone acesse pelo link:
https://marcosnunes.github.io/autossuficiencia
